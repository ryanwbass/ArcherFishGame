The game was made with javascript in chrome, 
just open the index.html in chrome and it should be good